/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugaspbo;

/**
 *
 * @author Risyadian
 */
public class Customer {
    private String name;
    private static int jumlahCustomer;
    
    // Overloading constructor
    // cus 1
    Customer(String name){
        Customer.jumlahCustomer++;
        this.name = name;
    }
    
    // cus 2
    Customer(){
        Customer.jumlahCustomer++;
        this.name = "Customer" + Customer.jumlahCustomer;
    }
    
    void show(){
        System.out.println("Nama : " + this.name);
    }
}
