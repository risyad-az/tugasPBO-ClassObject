/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugaspbo;
/**
 * @author Risyadian
 */
public class superMarket {
    String lokasi;
    int jumlahLantai;
    
    superMarket(String l, int jl) {
        this.lokasi = l;
        this.jumlahLantai = jl;
        
        System.out.println("Selamat Datang di Supermarket Pusat Kota! ^^");
    }
    
    void buka(){
        System.out.println("Supermarket buka 24 jam");
    }
    
    void tutup() {
        System.out.println("Supermarket tutup pada hari libur keagamaan^^");
    }
    
    void tampilData() {
        System.out.println("Lokasi : " +this.lokasi);
        System.out.println("Jumlah lantai : " +this.jumlahLantai);
    }
}
