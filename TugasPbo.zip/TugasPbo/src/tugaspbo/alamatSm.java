/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugaspbo;

/**
 *
 * @author Risyadian
 */
class alamatSm {
    private String namaJalan;
    private int noJalan;
    private String ket;
    
    public String get_namaJalan(){
        return namaJalan;
    }
    public void set_namaJalan(String namaJalan){
        this.namaJalan = namaJalan;
    }
    
    public int get_noJalan(){
        return noJalan;
    }
    public void set_noJalan(int noJalan){
        this.noJalan = noJalan;
    }
}
