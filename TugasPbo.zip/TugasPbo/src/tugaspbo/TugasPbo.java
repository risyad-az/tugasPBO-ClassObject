/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugaspbo;

/**
 *
 * @author Risyadian
 */
class TugasPbo {
    public static void main(String[] args) {
        superMarket wSupermarket = new superMarket("Pusat kota", 2);
        wSupermarket.buka();
        wSupermarket.tutup();
        wSupermarket.tampilData();
        System.out.println("\n");
        
//        overloading pada constructor
            Customer custom1 = new Customer("Deuce Spades");
            Customer custom2 = new Customer("Ace Trappola");
            Customer custom3 = new Customer();
            Customer custom4 = new Customer();
            
            custom1.show();
            custom2.show();
            custom3.show();
            custom4.show();
        
        
        System.out.println("\n");
        
        alamatSm al = new alamatSm();
        al.set_namaJalan("jl Lurus ");
        al.set_noJalan(55);
        
        System.out.println(al.get_namaJalan() + al.get_noJalan());
    }
    
}
